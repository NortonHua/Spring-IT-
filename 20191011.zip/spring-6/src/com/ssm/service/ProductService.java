package com.ssm.service;

public interface ProductService {
	// 定义一个抽象方法browse，模拟用户浏览商品
	public void browse(String loginName,String productName);
}
