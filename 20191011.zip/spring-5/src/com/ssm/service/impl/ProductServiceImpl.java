package com.ssm.service.impl;

import com.ssm.service.ProductService;

public class ProductServiceImpl implements ProductService {
	// 实现方法browse，模拟用户浏览商品
	@Override
	public void browse(String loginName, String productName) {
		System.out.println("执行业务方法browse…");
		//演示异常通知时，手动人为抛出异常
		/*throw new RuntimeException("这是特意手动抛出的异常信息！");*/
		int i=100000000;
		while(i>0) {
			i--;
		}
	}

}
