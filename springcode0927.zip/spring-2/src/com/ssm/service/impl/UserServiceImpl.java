package com.ssm.service.impl;

import com.ssm.dao.UserDAO;
import com.ssm.service.UserService;

public class UserServiceImpl implements UserService {
	
	//使用接口UserDAO声明对象，添加相应的setter方法，用于依赖注入
	UserDAO userDAO;
	public void setUserDAO(UserDAO userDAO) {
		this.userDAO = userDAO;
	}
	//实现接口中的login方法
	@Override
	public boolean login(String loginName, String loginPwd) {
		return userDAO.login(loginName, loginPwd);
	}

}
