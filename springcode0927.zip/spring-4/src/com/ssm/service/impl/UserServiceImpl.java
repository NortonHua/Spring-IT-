package com.ssm.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssm.dao.UserDAO;
import com.ssm.service.UserService;
@Service("userService")
public class UserServiceImpl implements UserService {
	
	//使用接口UserDAO声明对象，
	@Autowired
	UserDAO userDAO;
	
	//实现接口中的login方法
	@Override
	public boolean login(String loginName, String loginPwd) {
		return userDAO.login(loginName, loginPwd);
	}

}
