package com.ssm.dao;

public interface UserDAO {
	public boolean login(String loginName,String loginPwd);
}
